# IJA
## Autoři
- Adam Nieslanik (xniesl00)
- Marcin Sochacki (xsocha03)

## Popis
* Jednoduchá 2D hra, která simuluje pohyb robotů mezi překážkami.
* Rozlišuje 2 typy robotů:
  * Autonomní
  * Dálkově ovladaný

## Spuštění
1. `mvn clean compile`
2. `mvn clean javafx:run`

## Dokumentace
- Dokumentaci lze vygenerovat následujícím příkazem:
`mvn javadoc:javadoc`
